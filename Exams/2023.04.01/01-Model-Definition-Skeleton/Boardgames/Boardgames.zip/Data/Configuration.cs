﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=.\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Trust Server Certificate=true";
    }
}

