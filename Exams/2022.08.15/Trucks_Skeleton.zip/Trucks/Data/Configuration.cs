﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @".;Database=Trucks;Trusted_Connection=True";
    }
}