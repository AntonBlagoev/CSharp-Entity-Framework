﻿namespace P01_StudentSystem.Data.Models.Enum;

public enum ContentType
{
    Application,
    Pdf,
    Zip
}
