﻿namespace P01_StudentSystem.Data.Common;

public class DbConfig
{
    public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=StudentSystem;Integrated Security=true";
}